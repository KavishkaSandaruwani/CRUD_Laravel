-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 20, 2024 at 11:18 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `crud-op`
--

-- --------------------------------------------------------

--
-- Table structure for table `create_products`
--

CREATE TABLE `create_products` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `details` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `create_products`
--

INSERT INTO `create_products` (`id`, `name`, `details`, `created_at`, `updated_at`) VALUES
(1, 'Product A', 'Makeup brushes', '2024-09-16 14:16:42', '2024-09-17 04:56:37'),
(18, 'Product F', 'school items', '2024-09-17 05:14:02', '2024-09-18 01:46:09'),
(24, 'Product E', 'butterfly frock for baby girls', '2024-09-18 01:40:37', '2024-09-18 01:42:03'),
(26, 'Product B', 'mnxknaxnzm', '2024-09-19 00:00:57', '2024-09-20 02:41:17');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `create_products`
--
ALTER TABLE `create_products`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `create_products`
--
ALTER TABLE `create_products`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
